@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Creating Python virtual environment...
    python -m venv .venv
    if errorlevel 1 (
        echo Could not create virtual environment. Check that Python is installed and on PATH.
        pause
        exit /b 1
    )
)
echo Installing/checking dependencies...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo Dependency installation failed.
    pause
    exit /b 1
)
echo Starting ThreadPoolX at http://127.0.0.1:5000
".venv\Scripts\python.exe" app.py
pause
