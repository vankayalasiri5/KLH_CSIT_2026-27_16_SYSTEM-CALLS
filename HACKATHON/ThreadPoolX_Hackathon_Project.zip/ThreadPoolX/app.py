import time
import uuid
import threading
from queue import Queue
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)


class ThreadPool:
    def __init__(self, workers=3):
        self.task_queue = Queue()
        self.condition = threading.Condition(threading.RLock())
        self.tasks = {}
        self.paused = False
        self.closed = False
        self.worker_count = workers
        self.workers = []
        self.active_count = 0
        self.completed_count = 0
        self.failed_count = 0
        self.cancelled_count = 0
        self.start_workers(workers)

    def start_workers(self, count):
        for i in range(count):
            thread = threading.Thread(
                target=self.worker, name=f"Worker-{i + 1}", daemon=True
            )
            self.workers.append(thread)
            thread.start()

    def submit(self, duration=3, should_fail=False):
        task_id = uuid.uuid4().hex[:8]
        task = {
            "id": task_id,
            "name": f"Task-{task_id}",
            "duration": duration,
            "status": "Pending",
            "worker": "-",
            "created_at": time.time(),
            "started_at": None,
            "finished_at": None,
            "execution_time": None,
            "error": None,
            "should_fail": should_fail,
        }
        with self.condition:
            if self.closed:
                raise RuntimeError("Thread pool is shut down. Restart the app.")
            self.tasks[task_id] = task
            self.task_queue.put(task_id)
            self.condition.notify_all()
        return task

    def worker(self):
        worker_name = threading.current_thread().name
        while True:
            task_id = self.task_queue.get()
            try:
                if task_id is None:
                    return
                with self.condition:
                    while self.paused and not self.closed:
                        self.condition.wait()
                    task = self.tasks.get(task_id)
                    if not task or task["status"] != "Pending":
                        continue
                    task["status"] = "Running"
                    task["worker"] = worker_name
                    task["started_at"] = time.time()
                    self.active_count += 1

                try:
                    # Simulated I/O-style work for the prototype.
                    time.sleep(task["duration"])
                    if task["should_fail"]:
                        raise ValueError("Simulated task failure")
                    with self.condition:
                        task["status"] = "Completed"
                        task["finished_at"] = time.time()
                        task["execution_time"] = round(
                            task["finished_at"] - task["started_at"], 3
                        )
                        self.completed_count += 1
                except Exception as exc:
                    with self.condition:
                        task["status"] = "Failed"
                        task["error"] = str(exc)
                        task["finished_at"] = time.time()
                        task["execution_time"] = round(
                            task["finished_at"] - task["started_at"], 3
                        )
                        self.failed_count += 1
                finally:
                    with self.condition:
                        self.active_count -= 1
                        self.condition.notify_all()
            finally:
                self.task_queue.task_done()

    def cancel(self, task_id):
        with self.condition:
            task = self.tasks.get(task_id)
            if not task or task["status"] != "Pending":
                return False
            task["status"] = "Cancelled"
            task["finished_at"] = time.time()
            self.cancelled_count += 1
            return True

    def pause(self):
        with self.condition:
            if self.closed:
                raise RuntimeError("Thread pool is shut down")
            self.paused = True

    def resume(self):
        with self.condition:
            if self.closed:
                raise RuntimeError("Thread pool is shut down")
            self.paused = False
            self.condition.notify_all()

    def snapshot(self):
        with self.condition:
            now = time.time()
            result = []
            for task in self.tasks.values():
                item = task.copy()
                item.pop("should_fail", None)
                item["created_at"] = round(item["created_at"], 2)
                if item["started_at"] is not None:
                    item["started_at"] = round(item["started_at"], 2)
                if item["finished_at"] is not None:
                    item["finished_at"] = round(item["finished_at"], 2)
                elif item["status"] == "Running":
                    item["elapsed_time"] = round(now - item["started_at"], 2)
                result.append(item)
            result.sort(key=lambda item: item["created_at"], reverse=True)
            return {
                "tasks": result,
                "workers": self.worker_count,
                "active": self.active_count,
                "pending": sum(t["status"] == "Pending" for t in self.tasks.values()),
                "completed": self.completed_count,
                "failed": self.failed_count,
                "cancelled": self.cancelled_count,
                "total": len(self.tasks),
                "paused": self.paused,
                "closed": self.closed,
                "queue_size": self.task_queue.qsize(),
            }

    def shutdown(self):
        with self.condition:
            if self.closed:
                return
            self.closed = True
            self.paused = False
            self.condition.notify_all()
            for task in self.tasks.values():
                if task["status"] == "Pending":
                    task["status"] = "Cancelled"
                    task["finished_at"] = time.time()
                    self.cancelled_count += 1
            for _ in self.workers:
                self.task_queue.put(None)
        for thread in self.workers:
            thread.join(timeout=5)


pool = ThreadPool(workers=3)


@app.route("/")
def home():
    return render_template("index.html")


@app.get("/api/status")
def status():
    return jsonify(pool.snapshot())


@app.post("/api/tasks")
def add_task():
    data = request.get_json(silent=True) or {}
    try:
        duration = float(data.get("duration", 3))
        if not 0.5 <= duration <= 15:
            return jsonify({"error": "Duration must be between 0.5 and 15 seconds"}), 400
        task = pool.submit(duration, bool(data.get("should_fail", False)))
        return jsonify({"message": "Task submitted", "task_id": task["id"]}), 201
    except (ValueError, TypeError) as exc:
        return jsonify({"error": str(exc) or "Invalid duration"}), 400
    except RuntimeError as exc:
        return jsonify({"error": str(exc)}), 409


@app.post("/api/batch")
def add_batch():
    data = request.get_json(silent=True) or {}
    try:
        count = int(data.get("count", 5))
        duration = float(data.get("duration", 3))
        if not 1 <= count <= 100:
            return jsonify({"error": "Batch size must be between 1 and 100"}), 400
        if not 0.5 <= duration <= 15:
            return jsonify({"error": "Duration must be between 0.5 and 15 seconds"}), 400
        ids = [pool.submit(duration)["id"] for _ in range(count)]
        return jsonify({"message": f"{count} tasks submitted", "task_ids": ids}), 201
    except (ValueError, TypeError) as exc:
        return jsonify({"error": str(exc) or "Invalid input"}), 400
    except RuntimeError as exc:
        return jsonify({"error": str(exc)}), 409


@app.post("/api/tasks/<task_id>/cancel")
def cancel_task(task_id):
    if pool.cancel(task_id):
        return jsonify({"message": "Pending task cancelled"})
    return jsonify({"error": "Task not found or already started"}), 409


@app.post("/api/pause")
def pause():
    try:
        pool.pause()
        return jsonify({"message": "Pool paused"})
    except RuntimeError as exc:
        return jsonify({"error": str(exc)}), 409


@app.post("/api/resume")
def resume():
    try:
        pool.resume()
        return jsonify({"message": "Pool resumed"})
    except RuntimeError as exc:
        return jsonify({"error": str(exc)}), 409


@app.post("/api/shutdown")
def shutdown():
    threading.Thread(target=pool.shutdown, daemon=True).start()
    return jsonify({"message": "Shutdown requested"})


if __name__ == "__main__":
    try:
        app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
    finally:
        pool.shutdown()
