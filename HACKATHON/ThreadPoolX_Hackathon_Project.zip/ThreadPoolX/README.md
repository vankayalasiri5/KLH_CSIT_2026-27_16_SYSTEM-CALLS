# ThreadPoolX — Thread Pool Based Task Processing System

An Operating Systems hackathon prototype that demonstrates a fixed-size thread pool, a thread-safe task queue, concurrent workers, task cancellation, pause/resume, and a live web dashboard.

## Requirements
- Python 3.10 or newer
- VS Code (recommended)

## Run on Windows using VS Code

1. Extract the ZIP and open the `ThreadPoolX` folder in VS Code.
2. Open **Terminal → New Terminal**.
3. Create a virtual environment:

   ```powershell
   python -m venv .venv
   ```

4. Install dependencies:

   ```powershell
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
   ```

5. Start the app:

   ```powershell
   .\.venv\Scripts\python.exe app.py
   ```

6. Open your browser at http://127.0.0.1:5000

Keep the terminal open while using the dashboard. Press `Ctrl+C` in the terminal to stop the server.

### If `python` is not recognized
Install Python from https://www.python.org/downloads/ and enable **Add Python to PATH**, or replace `python` in step 3 with `py`.

### PowerShell activation alternative
If you prefer activation and it is permitted by your PowerShell policy:

```powershell
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

## Demo checklist
1. Submit one task and observe Pending → Running → Completed.
2. Submit a batch of 10 tasks and watch the three workers.
3. Pause and resume the pool.
4. Cancel a task while it is Pending.
5. Shut down the pool last. Restart `app.py` to start a fresh pool.

## Project structure
```text
ThreadPoolX/
├── app.py
├── requirements.txt
├── README.md
├── run_windows.bat
└── templates/
    └── index.html
```

## Concepts demonstrated
- Thread creation and reuse
- Producer-consumer pattern
- Thread-safe queue
- Mutual exclusion and condition variables
- Concurrency and bounded worker count
- Task status, cancellation, error handling, and shutdown

## Notes
- Tasks use `time.sleep()` to simulate I/O-style work; replace this with actual workload functions for a real application.
- This is an educational prototype, not a kernel scheduler.
- The worker count is set to three in `app.py`.
- Task and statistics data live in memory and reset when the application restarts.
